import webbrowser
import threading
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles
import asyncio

selected_location = {}
app = FastAPI()
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

class Location(BaseModel):
    lat: float
    lng: float

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/submit_location")
async def submit_location(location: Location):
    selected_location['lat'] = location.lat
    selected_location['lng'] = location.lng
    return {"status": "ok"}

def run_server():
    uvicorn.run(app, host="127.0.0.1", port=8000)

def get_location():
    thread = threading.Thread(target=run_server, daemon=True)
    thread.start()
    webbrowser.open("http://127.0.0.1:8000")
    print("Waiting for user to select a location...")

    while 'lat' not in selected_location:
        asyncio.run(asyncio.sleep(0.2))

    return selected_location['lat'], selected_location['lng']
